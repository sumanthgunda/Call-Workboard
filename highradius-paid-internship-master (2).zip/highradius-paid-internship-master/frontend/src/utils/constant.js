export const CARDS = Object.freeze({
  FIRST_CARD: "first",

  SIXTH_CARD: "sixth",
});
