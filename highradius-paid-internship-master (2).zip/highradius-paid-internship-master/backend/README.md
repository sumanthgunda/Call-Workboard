# cls_mock_api

Mock API to provide sample data for Internship 2020.
